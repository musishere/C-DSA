#include <iostream>
#include <stack>
using namespace std;

struct BstNode
{
    int data;
    BstNode *left;
    BstNode *right;
};

class BinarySearchTree
{
public:
    BstNode *createNode(int data)
    {
        BstNode *newNode = new BstNode();
        newNode->data = data;
        newNode->right = newNode->left = nullptr;

        return newNode;
    }

    BstNode *Insertion(BstNode *root, int data)
    {
        if (root == nullptr)
        {
            root = createNode(data);
        }
        else if (data <= root->data)
        {
            root->left = Insertion(root->left, data);
        }
        else
        {
            root->right = Insertion(root->right, data);
        }
        return root;
    }

    bool SearchData(BstNode *root, int data)
    {
        if (root == nullptr)
        {
            return false;
        }
        else if (root->data == data)
        {
            return true;
        }
        else if (data <= root->data)
        {
            return SearchData(root->left, data);
        }
        else
        {
            return SearchData(root->right, data);
        }
    }

    void InorderTraversalIterative(BstNode *root)
    {
        stack<BstNode *> s;
        BstNode *current = root;
        while (current != nullptr || !s.empty())
        {
            while (current != nullptr)
            {
                s.push(current);
                current = current->left;
            }
            current = s.top();
            s.pop();
            cout << current->data << " ";
            current = current->right;
        }
    }

    void PostOrderTraversalIterative(BstNode *root)
    {
        if (root == nullptr)
            return;

        stack<BstNode *> s1, s2;
        s1.push(root);
        while (!s1.empty())
        {
            BstNode *current = s1.top();
            s1.pop();
            s2.push(current);
            if (current->left != nullptr)
                s1.push(current->left);
            if (current->right != nullptr)
                s1.push(current->right);
        }
        while (!s2.empty())
        {
            cout << s2.top()->data << " ";
            s2.pop();
        }
    }

    void PreOrderTraversalIterative(BstNode *root)
    {
        if (root == nullptr)
            return;

        stack<BstNode *> s;
        s.push(root);
        while (!s.empty())
        {
            BstNode *current = s.top();
            s.pop();
            cout << current->data << " ";
            if (current->right != nullptr)
                s.push(current->right);
            if (current->left != nullptr)
                s.push(current->left);
        }
    }

    int FindMinIterative(BstNode *root)
    {
        if (root == nullptr)
        {
            cout << "Error: Tree is Empty.";
            return -1; // or any other suitable value to indicate error
        }
        while (root->left != nullptr)
        {
            root = root->left;
        }
        return root->data;
    }

    int FindMaxIterative(BstNode *root)
    {
        if (root == nullptr)
        {
            cout << "Error: Tree is Empty.";
            return -1; // or any other suitable value to indicate error
        }
        while (root->right != nullptr)
        {
            root = root->right;
        }
        return root->data;
    }

    int FindDegreeIterative(BstNode *root, int data)
    {
        if (root == nullptr)
        {
            cout << "Error: Tree is empty.";
            return -1; // or any other suitable value to indicate error
        }
        while (root != nullptr)
        {
            if (root->data == data)
            {
                int degree = 0;
                if (root->left != nullptr)
                {
                    degree++;
                }
                if (root->right != nullptr)
                {
                    degree++;
                }
                return degree;
            }
            if (data <= root->data)
            {
                root = root->left;
            }
            else
            {
                root = root->right;
            }
        }
        cout << "Error: Node not found.";
        return -1;
    }

    int CountLeafNodesIterative(BstNode *root)
    {
        if (root == nullptr)
            return 0;
        stack<BstNode *> s;
        s.push(root);
        int leafCount = 0;
        while (!s.empty())
        {
            BstNode *current = s.top();
            s.pop();
            if (current->left == nullptr && current->right == nullptr)
            {
                leafCount++;
            }
            if (current->right != nullptr)
                s.push(current->right);
            if (current->left != nullptr)
                s.push(current->left);
        }
        return leafCount;
    }

    int CountNodesIterative(BstNode *root)
    {
        if (root == nullptr)
            return 0;
        int nodeCount = 0;
        stack<BstNode *> s;
        s.push(root);
        while (!s.empty())
        {
            BstNode *current = s.top();
            s.pop();
            nodeCount++;
            if (current->right != nullptr)
                s.push(current->right);
            if (current->left != nullptr)
                s.push(current->left);
        }
        return nodeCount;
    }
};

int main()
{
    BstNode *root = nullptr;
    BinarySearchTree Tree;

    // Insertion:
    root = Tree.Insertion(root, 10);
    root = Tree.Insertion(root, 20);
    root = Tree.Insertion(root, 30);

    // Searching:
    int searchData;
    cout << "Enter Data To Search: ";
    cin >> searchData;
    if (Tree.SearchData(root, searchData))
    {
        cout << "Data Found";
    }
    else
    {
        cout << "Data not Found";
    }

    // Traversals:
    cout << endl
         << "In-order traversal: ";
    Tree.InorderTraversalIterative(root);
    cout << endl
         << "Pre-order traversal: ";
    Tree.PreOrderTraversalIterative(root);
    cout << endl
         << "Post-order traversal: ";
    Tree.PostOrderTraversalIterative(root);

    // Min Max
    cout << endl
         << "MAX VALUE: " << Tree.FindMaxIterative(root) << endl;
    cout << "MIN VALUE: " << Tree.FindMinIterative(root) << endl;

    // Degree:
    int degreeData;
    cout << "Enter Degree Data: ";
    cin >> degreeData;
    cout << "Degree of Node: " << Tree.FindDegreeIterative(root, degreeData) << endl;

    // Leaf Node:
    cout << "Leaf Nodes: " << Tree.CountLeafNodesIterative(root) << endl;

    // CountNode:
    cout << "Total Nodes: " << Tree.CountNodesIterative(root) << endl;
}

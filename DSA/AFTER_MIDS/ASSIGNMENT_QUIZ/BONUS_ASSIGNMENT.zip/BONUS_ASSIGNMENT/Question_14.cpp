// 14. Given an unsorted Linked List, the task is to remove duplicates from the list.
#include <iostream>
using namespace;
struct Node
{
    int data;
    Node *next;
};
class LinkedList
{
public:
    Node *head;
    LinkedList()
    {
        head = NULL;
    }

    void insertElement(int val)
    {
        Node *new_node = new Node;
        new_node->data = val;
        new_node->next = NULL;

        if (head == NULL)
        {
            head = new_node;
        }
        else
        {
            Node *temp = head;
            while (temp->next != NULL)
            {
                temp = temp->next;
            }
            temp->next = new_node;
        }
    }

    void DeleteNode(int val)
    {
        if (head == NULL)
        {
            cout << "Nothing to Delete. Linked List is Empty";
        }
        else
        {
            // if User wants to Delete First Node
            if (head->data == val)
            {
                Node *temp = head;
                head = head->next;
                delete temp;
            }
            else // user wants to delete middle or last node
            {
                Node *temp = head->next;
                Node *prev = head;
                while (temp != NULL)
                {
                    if (temp->data == val)
                    {
                        prev->next = temp->next;
                        delete temp;
                        break;
                    }
                    prev = temp;
                    temp = temp->next;
                }
            }
        }
    };

    void removeDuplicates()
    {
        Node *current = head;
        while (current != nullptr && current->next != nullptr)

        {
            Node *temp = current;

            while (temp->next != nullptr)
            {
                if (temp->next->data == current->data)
                {
                    Node *duplicate = temp->next;
                    temp->next = temp->next->next;
                    delete duplicate;
                }
                else
                {
                    temp = temp->next;
                }
            }
            current = current->next;
        }
    }

    void DisplayNode()
    {
        Node *temp = head;
        if (head == NULL)
        {
            cout << "Linked List is empty ";
        }
        else
        {
            while (temp != NULL)
            {
                cout << temp->data << " -> ";
                temp = temp->next;
            }
            cout << "NULL";
            cout << endl;
        }
    }
};
int main()
{
    // Input List: 12 -> 11 -> 12 -> 21 -> 41 -> 43 -> 21

    LinkedList List;
    List.insertElement(12);
    List.insertElement(11);
    List.insertElement(12);
    List.insertElement(21);
    List.insertElement(41);
    List.insertElement(43);
    List.insertElement(21);
    List.DisplayNode();
    cout << endl;
    cout << "After removing Duplicates: " << endl;
    List.removeDuplicates();
    List.DisplayNode();
}
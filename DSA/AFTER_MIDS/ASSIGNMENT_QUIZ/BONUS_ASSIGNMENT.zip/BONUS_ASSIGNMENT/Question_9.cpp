#include <iostream>
using namespace;
struct Node
{
    int data;
    Node *next;
};
class LinkedList
{
private:
    Node *head;

public:
    LinkedList()
    {
        head = NULL;
    }

    void insertion(int value)
    {
        Node *newNode = new Node;
        newNode->data = value;
        newNode->next = NULL;

        if (head == NULL)
        {
            head = newNode;
        }
        else
        {
            Node *temp = head;
            while (temp->next != NULL)
            {
                temp = temp->next;
            }
            temp->next = newNode;
        }
    }

    void DisplayLinkedList()
    {
        Node *temp = head;
        while (temp != NULL)
        {
            cout << temp->data << " -> ";
            temp = temp->next;
        }
        cout << "NULL" << endl;
    }

    void reverseByLinks()
    {
        Node *temp = head;
        Node *prev = NULL;
        while (temp != NULL)
        {
            Node *front = temp->next;
            temp->next = prev;
            prev = temp;
            temp = front;
        }
        head = prev;
    }
};
int main()
{
    LinkedList List;
    List.insertion(5);
    List.insertion(10);
    List.insertion(15);
    List.DisplayLinkedList();
    List.reverseByLinks();
    List.DisplayLinkedList();
}
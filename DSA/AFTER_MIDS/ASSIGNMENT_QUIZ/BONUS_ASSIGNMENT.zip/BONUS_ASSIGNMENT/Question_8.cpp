// Given a sorted array of positive integers, rearrange the array alternately i.e first element should be the maximum value, second minimum value, third - second max, fourth - second min and so on.
#include <iostream>
using namespace;
int main()
{
    int arr[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    int max = arr[0];
    int min = arr[0];
    int secondMax;
    int secondMin;

    for (int i = 0; i < 10; i++)
    {
        if (arr[i] > arr[i + 1])
        {
            max = arr[i];
            secondMax = arr[i - 1];
        }
        else if (arr[i] < arr[i + 1])
        {
            min = arr[i];
            secondMin = arr[i + 1];
        }
    }

    cout << min << " -> " << max << endl;
    cout << secondMax << " -> " << secondMin << endl;
}
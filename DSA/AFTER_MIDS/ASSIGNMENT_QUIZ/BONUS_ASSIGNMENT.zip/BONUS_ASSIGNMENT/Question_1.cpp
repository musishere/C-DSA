// 1. Given two sorted arrays, the task is to merge them in a sorted manner.

#include <iostream>
using namespace;
int BubbleSort(int arr[], int size)
{
    for (int i = 0; i < size; i++) // for array size
    {
        for (int i = 0; i < size - 1; i++) // for index size bcz index = size - 1
        {
            if (arr[i] > arr[i + 1])
            {
                swap(arr[i], arr[i + 1]);
            }
        }
    }

    // cout << "sorted array is: " << endl; // sorted output

    for (int i = 0; i < size; i++)
    {
        cout << arr[i] << " ";
    }
}
int main()
{
    int arr1[5];
    int arr2[5];
    int arr3[10];

    cout << "Enter 5 integer elements (array1):- " << endl;
    for (int i = 0; i < 5; i++)
    {
        cin >> arr1[i];
    }

    cout << "Enter 5 integer elements (array2):-" << endl;
    for (int i = 0; i < 5; i++)
    {
        cin >> arr2[i];
    }
    for (int i = 0; i < 5; i++)
    {
        arr3[i] = arr1[i];
        arr3[i + 5] = arr2[i];
    }

    cout << "Sorted Merged Array:- "
         << " ";
    BubbleSort(arr3, 10);
}
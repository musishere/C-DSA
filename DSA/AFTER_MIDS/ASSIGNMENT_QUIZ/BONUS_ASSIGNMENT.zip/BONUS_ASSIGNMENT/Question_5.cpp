// Given an array of integers, our task is to write a program that efficiently finds the second -largest element present in the array.
#include <iostream>
using namespace;
int SecondLargest(int arr[], int size)
{
    int largest = INT32_MIN;
    int secondLargest = INT32_MIN;

    for (int i = 0; i < size; ++i)
    {
        if (arr[i] > largest)
        {
            secondLargest = largest;
            largest = arr[i];
        }
        else if (arr[i] > secondLargest && arr[i] != largest)
        {
            secondLargest = arr[i];
        }
    }

    return secondLargest;
}
int main()
{
    int arr[10];
    cout << "Enter 10 integer values:- " << endl;
    for (int i = 0; i < 10; i++)
    {
        cin >> arr[i];
    }
    cout << "Second Largest Value of Array:- " << SecondLargest(arr, 10) << endl;
    ;
}
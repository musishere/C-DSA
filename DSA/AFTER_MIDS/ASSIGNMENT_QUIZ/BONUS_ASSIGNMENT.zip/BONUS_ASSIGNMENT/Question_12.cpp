// Given a Linked List and a number N, write a function that returns the value at the Nth
// node from the end of the Linked List.
#include <iostream>
#include <stack>
using namespace;
struct Node
{
    int data;
    Node *next;
};
class LinkedList
{
private:
    Node *head;

public:
    LinkedList()
    {
        head = NULL;
    }

    void insertion(int value)
    {
        Node *newNode = new Node;
        newNode->data = value;
        newNode->next = NULL;

        if (head == NULL)
        {
            head = newNode;
        }
        else
        {
            Node *temp = head;
            while (temp->next != NULL)
            {
                temp = temp->next;
            }
            temp->next = newNode;
        }
    }

    void reverseByData()
    {
        Node *temp = head;
        stack<int> st;
        while (temp != NULL)
        {
            st.push(temp->data);
            temp = temp->next;
        }
        temp = head;
        while (temp != NULL)
        {
            temp->data = st.top();
            st.pop();
            temp = temp->next;
        }
    }

    void ValueOfGivenNode(int position)
    {

        Node *temp = head;
        while (position != 1)
        {
            temp = temp->next;
            position--;
        }
        cout << temp->data << endl;
    }
};
int main()
{
    LinkedList List;
    List.insertion(35);
    List.insertion(15);
    List.insertion(4);
    List.insertion(20);
    List.reverseByData();
    List.ValueOfGivenNode(4);
}

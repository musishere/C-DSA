// Given an array of integers, find two numbers such that they add up to a specific target.
#include <iostream>
using namespace std;
void Found(int arr[], int size, int target)
{
    for (int i = 0; i < size; i++)
    {
        if (arr[i] + arr[i + 1] == target)
        {
            cout << arr[i] << " + " << arr[i + 1] << " = " << target << endl;
            break;
        }
        else
        {
            cout << "Nothing Found";
        }
    }
}
int main()
{
    int array[5];
    int target;
    int found;
    cout << "Enter 5 integer elements:- " << endl;
    for (int i = 0; i < 5; i++)
    {
        cin >> array[i];
    }

    cout << "Enter Target:- ";
    cin >> target;
    Found(array, 5, target);
}
// 6. Given an array, the task is to cyclically rotate the array clockwise by one time.
#include <iostream>
using namespace;
void rotateArray(int arr[], int n)
{
    int lastElement = arr[n - 1];

    for (int i = n - 1; i > 0; --i)
    {
        arr[i] = arr[i - 1];
    }

    arr[0] = lastElement;
}
int main()
{
    int arr[10];
    cout << "Enter 10 integer values:- " << endl;
    for (int i = 0; i < 10; i++)
    {
        cin >> arr[i];
    }

    rotateArray(arr, 10);
    cout << "Cyclically rotated Array:- ";
    for (int i = 0; i < 10; i++)
    {
        cout << arr[i] << " ";
    }
}
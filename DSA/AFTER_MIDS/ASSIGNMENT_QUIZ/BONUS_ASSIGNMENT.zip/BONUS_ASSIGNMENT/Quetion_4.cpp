// Given an array of integers of size N, the task is to find the first non - repeating element in this array.
#include <iostream>
using namespace;
void BubbleSort(int arr[], int size)
{
    for (int i = 0; i < size; i++) // for array size
    {
        for (int i = 0; i < size - 1; i++) // for index size bcz index = size - 1
        {
            if (arr[i] > arr[i + 1])
            {
                swap(arr[i], arr[i + 1]);
            }
        }
    }
}
int main()
{
    int repeat = 0;
    int non_repeat = 0;
    int arr[10];
    cout << "Enter 10 integer elements:- " << endl;
    for (int i = 0; i < 10; i++)
    {
        cin >> arr[i];
    }
    BubbleSort(arr, 10);
    for (int i = 0; i < 10; i++)
    {
        if (arr[i] == arr[i + 1])
        {
            repeat++;
        }
        else
        {
            non_repeat = arr[i];
        }
    }
    cout << "Non repeat element:- " << non_repeat << endl;
}
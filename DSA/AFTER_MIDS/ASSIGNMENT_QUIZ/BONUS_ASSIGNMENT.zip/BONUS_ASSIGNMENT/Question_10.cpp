// Given a linked list, check if the linked list has a loop (cycle) or not. The below diagram shows a linked list with a loop.
#include <iostream>
#include <unordered_map>
using namespace;
struct Node
{
    int data;
    Node *next;
};
class LinkedList
{
private:
    Node *head;

public:
    LinkedList()
    {
        head = NULL;
    }

    void insertion(int value)
    {
        Node *newNode = new Node;
        newNode->data = value;
        newNode->next = NULL;

        if (head == NULL)
        {
            head = newNode;
        }
        else
        {
            Node *temp = head;
            while (temp->next != NULL)
            {
                temp = temp->next;
            }
            temp->next = newNode;
        }
    }

    bool checkLoop()
    {
        Node *temp = head;
        unordered_map<Node *, int> mp;

        while (temp->next != NULL)
        {
            if (mp.find(temp) != mp.end())
            {
                return true;
            }
            mp[temp] = 1;
            temp = temp->next;
        }
        return false;
    }
};
int main()
{
    LinkedList List;
    List.insertion(5);
    List.insertion(10);
    List.insertion(15);
    if (List.checkLoop())
    {
        cout << "Loop found";
    }
    else
    {
        cout << "No Loop";
    }
}

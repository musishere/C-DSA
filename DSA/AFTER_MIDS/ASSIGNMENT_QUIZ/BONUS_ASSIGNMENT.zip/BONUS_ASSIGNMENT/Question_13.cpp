// Given two Linked Lists, create union and intersection lists that contain union and
// intersection of the elements present in the given lists.The order of elements in output lists
// doesn’t matter.
#include <iostream>
#include <stack>
using namespace;
struct Node
{
    int data;
    Node *next;
    Node(int value)
    {
        this->data = value;
        next = NULL;
    }
};

void mergeTwoList(Node *L1, Node *L2)
{
    stack<int> st;
}
int main()
{

    Node *l1 = new Node(1);
    l1->next = new Node(3);
    l1->next->next = new Node(5);
    l1->next->next->next = new Node(7);

    Node *l2 = new Node(2);
    l2->next = new Node(4);
    l2->next->next = new Node(6);
    l2->next->next->next = new Node(8);
}
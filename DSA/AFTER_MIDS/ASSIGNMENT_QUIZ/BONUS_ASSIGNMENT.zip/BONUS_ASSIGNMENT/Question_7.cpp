// An array contains both positive and negative numbers in random order.Rearrange thearray elements so that positive and negative numbers are placed alternatively.A numberof positive and negative numbers need not be equal.If there are more positive numbersthey appear at the end of the array.If there are more negative numbers, they too appear atthe end of the array.

#include <iostream>
using namespace;
class ReArrangeArray
{
private:
    int positve = 0;
    int negative = 0;

public:
    void BubbleSortAscending(int arr[], int size)
    {
        for (int i = 0; i < size; i++)
        {
            for (int i = 0; i < size - 1; i++)
            {
                if (arr[i] > arr[i + 1])
                {
                    swap(arr[i], arr[i + 1]);
                }
            }
        }

        for (int i = 0; i < size; i++)
        {
            cout << arr[i] << "  ";
        }
    }

    void BubbleSortDescending(int arr[], int size)
    {
        for (int i = 0; i < size; i++) // for array size
        {
            for (int i = 0; i < size - 1; i++) // for index size bcz index = size - 1
            {
                if (arr[i] < arr[i + 1])
                {
                    swap(arr[i], arr[i + 1]);
                }
            }
        }

        // cout << "sorted array is: " << endl; // sorted output
        for (int i = 0; i < size; i++)
        {
            cout << arr[i] << "  ";
        }
    }

    void RearrangeArray(int arr[], int n)
    {
        for (int i = 0; i < n; i++)
        {
            if (arr[i] >= 0)
            {
                positve++;
            }
            else
            {
                negative++;
            }
        }
        if (positve > negative)
        {
            BubbleSortDescending(arr, 10);
        }
        else if (positve < negative)
        {
            BubbleSortAscending(arr, 10);
        }
        else
        {
            cout << "Enter valid numbers";
        }
    }
};
int main()
{
    ReArrangeArray re;
    int arr[10];
    cout << "Enter 10 Positive and Negative integer elements:- ";
    for (int i = 0; i < 10; i++)
    {
        cin >> arr[i];
    }

    re.RearrangeArray(arr, 10);
}